package com.demo;

import java.time.LocalDate;
import java.time.Month;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.demo.entities.Employee;
import com.demo.entities.Project;
import com.demo.repo.EmployeeRepo;
import com.demo.repo.ProjectRepo;

@SpringBootApplication
public class JpaManyToManyApplication implements CommandLineRunner{
	
@Autowired
private EmployeeRepo empRepo;
@Autowired
private ProjectRepo projectRepo;

	public static void main(String[] args) {
		SpringApplication.run(JpaManyToManyApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		Employee emp1 = new Employee("ekta", 4000.00);
		Employee emp2 = new Employee("ravi", 4000.00);
		Employee emp3 = new Employee("raju", 4000.00);
		
		Employee emp4 = new Employee("riya", 4000.00);
		Employee emp5 = new Employee("vikas", 4000.00);
		Employee emp6 = new Employee("raj", 4000.00);
		
		Project project1 = new Project("shopping cart","rajuu", LocalDate.of(2021, Month.JANUARY, 2));
		Project project2 = new Project(" bank app","rajesh", LocalDate.of(2020, Month.NOVEMBER, 8));
		
		
		project1.getEmployees().add(emp1);
		project1.getEmployees().add(emp2);
		project1.getEmployees().add(emp3);
		
		project2.getEmployees().add(emp4);
		project2.getEmployees().add(emp5);
		project2.getEmployees().add(emp6);
		
		emp1.getProjects().add(project1);
		emp2.getProjects().add(project1);
		emp3.getProjects().add(project1);
		
		emp4.getProjects().add(project2);
		emp5.getProjects().add(project2);
		emp6.getProjects().add(project2);
		
		projectRepo.save(project1);
		projectRepo.save(project2);
		
		empRepo.save(emp1);
		empRepo.save(emp2);
		empRepo.save(emp3);

		empRepo.save(emp4);
		empRepo.save(emp5);
		empRepo.save(emp6);
		
		
		
	}

}
